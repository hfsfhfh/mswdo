<?php
// Include the database connection file
include 'dbconn.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // SQL query to check if username and password exist in the database
    $query = "SELECT * FROM admin WHERE Username='$username' AND Password='$password'";
    
    // Execute the query
    $result = mysqli_query($conn, $query);

    // Check if the query returns any rows
    if (mysqli_num_rows($result) == 1) {
       // Add a success message
       $successMessage = "Successfully Login!";
       // Use JavaScript to display the success message and redirect
       echo "<script>
               alert('$successMessage');
               window.location.href = 'home.php';
             </script>";
       exit();
    } else {
        // User not found
        $errorMessage = "User not found";

        // Display the error message as an alert and go back to qrlogin.php
        echo "<script>
                alert('$errorMessage');
                window.location.href = 'index.php';
              </script>";
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MSWDO Management System - Login</title>
    <link rel="stylesheet" href="styles.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-LnRWLIRIavMfE5f3VWuC+1mv7t+kZJZ6lslkLtgGaM/6fcuWskODaSq6ZtzPk3bvrXOIRsgWhafSq+RsacImvQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="db.png" alt="MSWDO Logo">
        </div>
        <h2>ACCOUNT LOGIN</h2>
        <div class="black-line"></div>
        <form action="index.php" method="post">
            <div class="form-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" id="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" id="password" placeholder="Password" required>
                <span class="toggle-password"><i class="fas fa-eye-slash"></i></span>
            </div>
            <div class="remember-me">
                <input type="checkbox" id="remember_me">
                <label for="remember_me">Remember Me</label>
            </div>
            <div class="forgot-password">
                <a href="forgot_password.php">Forgot Password?</a>
            </div>
            <div class="form-group">
                <button type="submit" class="btn">Login</button>
            </div>
        </form>
        
    </div>
    <script src="script.js"></script>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MSWDO</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <style>
        :root{
            --bs-success-rgb:71, 222, 152 !important;
        }
        body{
            background-color: #E5E7E9;
        }
        .navbar-brand{
            margin-right: 100px;
            font-weight: 500;
        }
        .nav-item{
            margin-right: 30px;
        }
        .nav-item .nav-link {
        transition: transform 0.3s ease-out; /* Transition property for smooth upward movement */
    }

    .nav-item:hover .nav-link {
        transform: translateY(-5px); /* Move the element upward by 5 pixels on hover */
    }
        html,body{
            height:100%;
            width:100%;
        }
        main{
            height:100%;
            display:flex;
            flex-flow:column;
        }
        #page-container{
            flex: 1 1 auto; 
            overflow:auto;
        }
        #topNavBar{
            flex: 0 1 auto; 
        }
        .thumbnail-img{
            width:50px;
            height:50px;
            margin:2px
        }
        .truncate-1 {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
        }
        .truncate-3 {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
        }
        .modal-dialog.large {
            width: 80% !important;
            max-width: unset;
        }
        .modal-dialog.mid-large {
            width: 50% !important;
            max-width: unset;
        }
        @media (max-width:720px){
            
            .modal-dialog.large {
                width: 100% !important;
                max-width: unset;
            }
            .modal-dialog.mid-large {
                width: 100% !important;
                max-width: unset;
            }  
        
        }
        .display-select-image{
            width:60px;
            height:60px;
            margin:2px
        }
        img.display-image {
            width: 100%;
            height: 45vh;
            object-fit: cover;
            background: black;
        }
        /* width */
        ::-webkit-scrollbar {
        width: 5px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
        background: #f1f1f1; 
        }
        
        /* Handle */
        ::-webkit-scrollbar-thumb {
        background: #888; 
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
        background: #555; 
        }
        .img-del-btn{
            right: 2px;
            top: -3px;
        }
        .img-del-btn>.btn{
            font-size: 10px;
            padding: 0px 2px !important;
        }
        span.select2-container.select2-container--default.select2-container--open {
            z-index: 9999;
        }
        table{
            margin: 50px 0 0 170px;
        }
         .dropdown-toggle {
            padding: 10px 20px 10px 20px; /* Adjust padding as needed */
        }
        .btn-group{
            margin: 20px 0 20px 0;
        }
        .row{
            margin: 0 0 0 200px;
        }
        .view{
            margin-left: 10px;
            font-weight: 400;
        }
        .count{
            font-weight: bold;
        }
        .card-lgu{
            margin: 50px 30px 0 0 ;
        }
        #imageCarousel{
            margin: 50px 0 0 290px;
        }
        </style>
</head>
<body>
    <main>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary bd-cyan-800 bg-gradient" id="topNavBar">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img class="img-thumbnail rounded-circle bg-primary" style="width: 53px; height: 53px; border: none;"
                                    src="lgu.png">
                <img class="img-thumbnail bg-primary" style="width: 55px; height: 55px; border:none;"
                                    src="logo2.png">
            MSWDO
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link text-white" aria-current="page" href="home.php"><i class="fa fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="household.php"><i class="fa fa-users"></i> Households</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="aics.php"><i class="fa-solid fa-suitcase-medical"></i> AICS</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link text-white " href="smb.php"><i class="fa-solid fa-coins"></i> SMB</a>
                    </li>
                   
                    <li class="nav-item">
                        <a class="nav-link text-white" aria-current="page" href="slp.php"><i class="fa-solid fa-seedling"></i> SLP</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link text-white" aria-current="page" href="lgu.php"><i class="fa-solid fa-gift"></i> LGU</a>
                    </li>
                </ul>
            </div>
            <div>
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle bg-transparent  text-light border-0" type="button" id="dropdownMenuButton1" data-toggle="dropdown" aria-expanded="false">
                    Administrator
                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item" href="admin.php">Manage Account</a></li>
                    <li><a class="dropdown-item" href="index.php
                    ">Logout</a></li>
                </ul>
            </div>
            </div>
        </div>
    </nav>
    
    <div class="row mt-5">
                        
        <div class="col-md-2 mr-1">
            <div class="card  shadow h-100 py-2">
                <center>
                <p class="count text-xs  text-primary text-uppercase mb-1 mt-2">Households</p>
                <h2 class="h5 mb-4 font-weight-bold text-gray-800 mt-2">
                5
                </h2></center>
              
            </div>
        </div>

                        
        <div class="col-md-2 mr-1">
            <div class="card border-left-success shadow h-100 py-2">
                <center>
                <p class="count text-xs text-primary text-uppercase mb-1 mt-2">AICS</p>
                <h2 class="h5 mb-4 font-weight-bold text-gray-800 mt-2">
                10
                </h2></center>
                

            </div>
        </div>

        <div class="col-md-2 mr-1">
            <div class="card border-left-success shadow h-100 py-2">
                <center>
                <p class="count text-xs  text-primary text-uppercase mb-1 mt-2">SMB</p>
                <h2 class="h5 mb-4 font-weight-bold text-gray-800 mt-2">
                15
                </h2></center>
             

            </div>
        </div>

        <div class="col-md-2 mr-1">
            <div class="card border-left-primary shadow h-100 py-2">
                <center>
                <p class="count text-xs  text-primary text-uppercase mb-1 mt-2">SLP</p>
                <h2 class="h5 mb-4 font-weight-bold text-gray-800 mt-2">
                20
                </h2></center>
                

            </div>
        </div>

        
        <div class="col-md-2">
            <div class="card border-left-warning shadow h-100 py-2">
                <center>
                <p class="count text-xs  text-primary text-uppercase mb-1 mt-2">LGU</p>
                <h2 class="h5 mb-4 font-weight-bold text-gray-800 mt-2 mb-1">
               25
                </h2></center>
                

            </div>
        </div>

        <div id="imageCarousel" class="carousel slide" data-ride="carousel" style="max-width: 400px;">
            <div class="carousel-inner">
                <!-- Carousel items -->
                <div class="carousel-item active">
                    <img src="aics.png" class="d-block w-100" alt="Image 1" style="max-width: 100%; height: auto;">
                </div>
                <div class="carousel-item">
                    <img src="smb.png" class="d-block w-100" alt="Image 2" style="max-width: 100%; height: auto;">
                </div>
                <div class="carousel-item">
                    <img src="slp.png" class="d-block w-100" alt="Image 3" style="max-width: 100%; height: auto;">
                </div>
                <div class="carousel-item">
                    <img src="lgu2.png" class="d-block w-100" alt="Image 4" style="max-width: 100%; height: auto;">
                </div>
            </div>
        </div>
    <!-- Add more carousel items as needed -->
    
    <!-- Content Section 
    <section class="container mt-5">
        <h1>Welcome to MSWDO</h1>
        <p>This is the official website of Municipality of Daanbantayan MSWDO (Municipal Social Welfare and Development Office).</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget felis condimentum, eleifend turpis eget, fermentum odio. Phasellus nec leo vel libero sodales bibendum. Curabitur eget magna id lacus mattis rutrum. Fusce vel nisi nec est aliquet tristique non eu quam. Integer nec metus orci. Ut tempus purus id dolor interdum, at egestas est eleifend. Nunc volutpat justo sed velit fermentum dapibus. Phasellus mollis arcu id feugiat lobortis. Maecenas rutrum orci vel magna lacinia, id condimentum est fermentum. Nulla viverra mauris a justo tempus eleifend.</p>
    </section>
    
    <div class="row">
    <div class="card card-lgu" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Vision</h5>
    <p class="card-text">The Municipal Social Welfare and Development office envisions all our constituents to have equal access to opportunities for an improved quality of life through effective and efficient delivery of social services. Towards this end, office will promote compassion, empowerment, gender equality and justice by 2030.</p>
    
  </div>
</div>

<div class="card card-lgu" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title">Mission</h5>
    <p class="card-text">The Municipality Social Welfare and Development office shall be socially responsible in serving all our constituents in providing quality services and looking for effective ways relative to distressed, disadvantaged individuals or families.</p>
    
  </div>
</div>

<div class="card card-lgu" style="width: 18rem;">
  
  <div class="card-body">
    <h5 class="card-title">Goals</h5>
    <p class="card-text">The Municipal Social Welfare and Development office aims to achieve the following goals:<br><br>
    1. To provide an integrated welfare package to its constituents on the basis of their needs. <br><br>
    2. To formulate, develop and implement plans, programs and projects in the field of social devbelopment with non-government organizations. <br><br>
    3. To have a network with Government and non-government agencies to assist in the uplifting of the living of conditions of people belonging to poverty threshold.</p>

    
  </div>
</div>-->
</div>

    </main>
   
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#imageCarousel').carousel({
                interval: 3000,
                pause: 'hover'
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>

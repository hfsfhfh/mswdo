<?php
require('dbconn.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MSWDO</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <style>
        :root{
            --bs-success-rgb:71, 222, 152 !important;
        }
        body{
            background-color: #E5E7E9;
        }
        .navbar-brand{
            margin-right: 100px;
            font-weight: 500;
        }
        .nav-item{
            margin-right: 30px;
        }
        .nav-item .nav-link {
        transition: transform 0.3s ease-out; /* Transition property for smooth upward movement */
    }

    .nav-item:hover .nav-link {
        transform: translateY(-5px); /* Move the element upward by 5 pixels on hover */
    }
        html,body{
            height:100%;
            width:100%;
        }
        main{
            height:100%;
            display:flex;
            flex-flow:column;
        }
        #page-container{
            flex: 1 1 auto; 
            overflow:auto;
        }
        #topNavBar{
            flex: 0 1 auto; 
        }
        .thumbnail-img{
            width:50px;
            height:50px;
            margin:2px
        }
        .truncate-1 {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
        }
        .truncate-3 {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
        }
        .modal-dialog.large {
            width: 80% !important;
            max-width: unset;
        }
        .modal-dialog.mid-large {
            width: 50% !important;
            max-width: unset;
        }
        @media (max-width:720px){
            
            .modal-dialog.large {
                width: 100% !important;
                max-width: unset;
            }
            .modal-dialog.mid-large {
                width: 100% !important;
                max-width: unset;
            }  
        
        }
        .display-select-image{
            width:60px;
            height:60px;
            margin:2px
        }
        img.display-image {
            width: 100%;
            height: 45vh;
            object-fit: cover;
            background: black;
        }
        /* width */
        ::-webkit-scrollbar {
        width: 5px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
        background: #f1f1f1; 
        }
        
        /* Handle */
        ::-webkit-scrollbar-thumb {
        background: #888; 
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
        background: #555; 
        }
        .img-del-btn{
            right: 2px;
            top: -3px;
        }
        .img-del-btn>.btn{
            font-size: 10px;
            padding: 0px 2px !important;
        }
        span.select2-container.select2-container--default.select2-container--open {
            z-index: 9999;
        }
        table{
            margin: 20px 0 0 170px;
        }
         .dropdown-toggle {
            padding: 10px 20px 10px 20px; /* Adjust padding as needed */
        }
        .btn-group{
            margin: 20px 0 20px 0;
        }
        thead{
            background-color: #cdcdcf;
        }.search{
            margin: 50px 0 0 140px;
        }
        
        </style>
</head>
<body>
    <main>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary bd-cyan-800 bg-gradient" id="topNavBar">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img class="img-thumbnail rounded-circle bg-primary" style="width: 53px; height: 53px; border: none;"
                                    src="lgu.png">
                <img class="img-thumbnail bg-primary" style="width: 55px; height: 55px; border:none;"
                                    src="logo2.png">
            MSWDO
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link text-white" aria-current="page" href="home.php"><i class="fa fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="household.php"><i class="fa fa-users"></i> Households</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="aics.php"><i class="fa-solid fa-suitcase-medical"></i> AICS</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link text-white " href="smb.php"><i class="fa-solid fa-coins"></i> SMB</a>
                    </li>
                   
                    <li class="nav-item">
                        <a class="nav-link text-white" aria-current="page" href="slp.php"><i class="fa-solid fa-seedling"></i> SLP</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link text-white" aria-current="page" href="lgu.php"><i class="fa-solid fa-gift"></i> LGU</a>
                    </li>
                </ul>
            </div>
            <div>
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle bg-transparent  text-light border-0" type="button" id="dropdownMenuButton1" data-toggle="dropdown" aria-expanded="false">
                    Administrator
                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item" href="admin.php">Manage Account</a></li>
                    <li><a class="dropdown-item" href="index.php
                    ">Logout</a></li>
                </ul>
            </div>
            </div>
        </div>
    </nav>



    <form class="search form-horizontal row-fluid" action="" method="post">
                                        <div class="control-group row">


                                        <button type="button" class="btn btn-primary ml-5" onclick="redirectToPage()"> <i class="far fa-user pr-2" aria-hidden="true"></i>Add New User</button>

                                            <div class="input-group w-50">
                                                <input type="text"  name="Textbook" placeholder="" class="form-control bg-light border-0 small ml-5" required>
                                                <button type="submit" name="submit"class="btn btn-primary ml-2"><i class="fa-solid fa-magnifying-glass"></i></button>
                                            </div>

                                            <button type="button" class="btn btn-primary ml-5"><i class="fa-solid fa-download"></i> Export</button>

                                        </div>
                                    </form>

    <?php

// Fetch data from the 'household' table
$sql = "SELECT * FROM household";
$result = mysqli_query($conn, $sql);

// Start table HTML
echo "<table class='table table-bordered w-75'>";
echo "<thead>";
echo "<tr>";
echo "<th>ID</th>";
echo "<th>Name</th>";
echo "<th>Age</th>";
echo "<th>Sitio</th>";
echo "<th>Barangay</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

// Check if there are any records
if (mysqli_num_rows($result) > 0) {
    // Output data of each row
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td class='bg-light'>" . $row["ID"] . "</td>";
        echo "<td class='bg-light'>" . $row["Name"] . "</td>";
        echo "<td class='bg-light'>" . $row["Age"] . "</td>";
        echo "<td class='bg-light'>" . $row["Sitio"] . "</td>";
        echo "<td class='bg-light'>" . $row["Barangay"] . "</td>";
        echo "</tr>";
    }
} else {
    // If no results, display a single row indicating no results
    echo "<tr>";
    echo "<td colspan='5'>No results found</td>";
    echo "</tr>";
}

// Close table HTML
echo "</tbody>";
echo "</table>";

mysqli_close($conn);
?>
    
    </main>
   
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script>
  function redirectToPage() {
    // Replace 'destination-page.html' with the URL of the page you want to redirect to
    window.location.href = 'add.php';
  }
</script>

</body>
</html>
